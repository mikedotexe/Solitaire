/*
 * The main point of this class is to be a superclass for SmartPlayer and BlindPlayer
 * You could also have different players with different strategies
 * The key function they'll share in common is moveCardtoStack methods, and makeMove methods
 */
package solitaire;

import java.util.ArrayList;
import java.util.List;
import java.util.Stack;
import solitaire.SCard.Suit;

/**
 *
 * @author Mike
 */
public class SPlayer {
    Stack<String> moves = new Stack<String>(); // this will keep track of all the moves
    public SGame game; // stored in super so that both classes can access it
    
    // empty constructor
    public SPlayer(SGame game){
        this.game = game;
    }
    
    /*
     * This method is for moving a card to a SUIT STACK
     * It returns an integer of the correct stack pile IF the card can be moved there
     *  otherwise it returns -1
     */
    public int moveCardtStack(SCard card, SStack[] sstack){
        
        //boolean toReturn = false; // it'll get set to true "if can"
        int toReturn = -1; // it'll get set to true "if can"
        //System.out.println("LENGTH IS "+sstack.length);
        // This is where we're seeing if a card can be moved from (anywhere) to the suit stack
        // check to see suit space for card is empty, if so we're looking for an ACE
        Suit forCard = card.suit();
        // Loop through the Suit stack to see which one matches the suit
        for (int i=0; i<4;i++){
            if (sstack[i].up.isEmpty()) continue;
            if (forCard == sstack[i].up.peek().suit()){
                // found it!!!
                //System.out.println("found out which stack it is: "+i);
                // this looks tricky, but it's basically saying:
                // if the highest card in the suit stack is of ONE LESS ordinal value, add it
                if (card.rank().ordinal() - sstack[i].up.peek().rank().ordinal() == 1){
                    // this is where it CAN be done
                    //System.out.println("YOU CAN PUT THIS ON THE SUIT STACK");
                    toReturn = i;
                }
            }
        }
        return toReturn;
    }

    /*
     * This method is for moving a card to the 7 PILES
     */
    boolean moveCardtStack(SCard card, SStack sstack) {
        boolean toReturn = false;
        // This is a fancy if statement that says, if the rank on the stack is ONE HIGHER than 
        //  the card, AND one is BLACK and the other is RED
        if (card.rank() == SCard.Rank.KING && sstack.up.size() == 0 && sstack.down.size() == 0){
            return true; // had to return it like tihs because it's possible that the next else
                        // statement would throw an NullPointerException trying to peek at an empty slot
        }
        else if ((sstack.up.peek().rank().ordinal() - card.rank().ordinal() == 1) && 
                (card.isBlack() == sstack.up.peek().isRed())){
            //System.out.println("ATTENTION: Card "+card+" will fit under "+sstack.up.peek());
            toReturn = true;
        }
        return toReturn;
    }
    
}