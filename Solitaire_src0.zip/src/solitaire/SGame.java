/*
 * Initialize the game, by spreading out the deck
 * to the proper 7 piles
 */
package solitaire;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Stack;
import solitaire.SStack;

/**
 *
 * @author Mike
 */
public class SGame {
    public SStack[] suit = new SStack[4];
    public SStack[] pile = new SStack[7];
    public SStack reserve = new SStack();
    
    // constructor, called from Solitaire.java
    public SGame(ArrayList<String> arrDeck){
        // right now it's an array, make it into stack of card classes
        Stack<SCard> rawStack = new Stack<SCard>();
        
        // Initialize Suit stacks
        // Here we make a "fake" card with Enum of Zero so we can keep track of suits when empty
        // like at the beginning of the game.
        int i = 0; // we'll be using a lot of iterations right now
        
        
        for (i=0;i<4;i++){
            suit[i] = new SStack();
        }
        /*
        //SCard zeroSuit = new SCard(SCard.Rank.ZERO_SUIT_STACK, SCard.Suit.SPADES);
        SCard zeroSuit = new SCard(SCard.Rank.ZERO, SCard.Suit.SPADES);
        suit[0].up.add(zeroSuit);
        zeroSuit = new SCard(SCard.Rank.ZERO, SCard.Suit.CLUBS);
        //zeroSuit = new SCard(SCard.Rank.ZERO_SUIT_STACK, SCard.Suit.CLUBS);
        suit[1].up.add(zeroSuit);
        //zeroSuit = new SCard(SCard.Rank.ZERO_SUIT_STACK, SCard.Suit.DIAMONDS);
        zeroSuit = new SCard(SCard.Rank.ZERO, SCard.Suit.DIAMONDS);
        suit[2].up.add(zeroSuit);
        //zeroSuit = new SCard(SCard.Rank.ZERO_SUIT_STACK, SCard.Suit.HEARTS);
        zeroSuit = new SCard(SCard.Rank.ZERO, SCard.Suit.HEARTS);
        suit[3].up.add(zeroSuit);        
         */
         
        
        
        String cardStr = null, tmpFace = null, tmpSuit = null;
        Iterator it = arrDeck.iterator();        
        while (it.hasNext()){
            cardStr = (String) it.next().toString().trim();
            tmpFace = cardStr.substring(0, 1);
            tmpSuit = cardStr.substring(1, 2);
            SCard tmpSCard = new SCard(tmpFace, tmpSuit);
            //System.out.println(tmpFace+" of "+tmpSuit);
            rawStack.add(tmpSCard);
        }
        
        SCard tmpZero = new SCard("0","h");
        rawStack.add(tmpZero);
        tmpZero = new SCard("0","c");
        rawStack.add(tmpZero);
        tmpZero = new SCard("0","s");
        rawStack.add(tmpZero);
        tmpZero = new SCard("0","d");
        rawStack.add(tmpZero);
        
        
        //for debugging, this prints out the cards as toStrings
        /*
        System.out.println("test has "+ rawStack.size());
        for (i=0; i<rawStack.size();i++){
            //if (test.get(i) != null)
            System.out.println("WHATWEGOT: "+rawStack.get(i).toString());
        }
         */
        
        suit[0].up.add(rawStack.pop());
        suit[1].up.add(rawStack.pop());
        suit[2].up.add(rawStack.pop());
        suit[3].up.add(rawStack.pop());
        
        // now that the deck is in SCard classes, make SStacks
        
        for (i = 0;i<7;i++){
            pile[i] = new SStack();
        }
        
        
        pile[0] = new SStack();
        
        // Give the piles their cards, designating face up/down
        
        // Pile 1
        pile[0].up.add(rawStack.pop());
        // Pile 2
        for (i=0;i<1;i++){
            pile[1].down.add(rawStack.pop());
        }
        pile[1].up.add(rawStack.pop());
        // Pile 3
        for (i=0;i<2;i++){
            pile[2].down.add(rawStack.pop());
        }
        pile[2].up.add(rawStack.pop());
        // Pile 4
        for (i=0;i<3;i++){
            pile[3].down.add(rawStack.pop());
        }
        pile[3].up.add(rawStack.pop());
        // Pile 5
        for (i=0;i<4;i++){
            pile[4].down.add(rawStack.pop());
        }
        pile[4].up.add(rawStack.pop());
        // Pile 6
        for (i=0;i<5;i++){
            pile[5].down.add(rawStack.pop());
        }
        pile[5].up.add(rawStack.pop());
        // Pile 7
        for (i=0;i<6;i++){
            pile[6].down.add(rawStack.pop());
        }
        pile[6].up.add(rawStack.pop());
        
        /* for debugging, to confirm all the piles have the right amount
        for (i=0;i<7;i++){
            System.out.println("pile "+i+" has "+pile[i].down.size() +" down and "+pile[i].up.size()+" up");
        }
        // This shows there are 24 cards left for the reserve
        //System.out.println("the rest in rawStack is "+rawStack.size());
         */
        
        // Put the rest of the 24 cards in the reserve
        while (!rawStack.empty()){
            reserve.down.add(rawStack.pop());
        }
        

        
    }

    public void drawThree(){
        // This method draws three cards from the reserve pile (if there are three left)
        if (reserve.down.size() > 3){
            // should almost always land in this category
            // if there are already cards faced UP, put them into the bottom of the reserve stack
            if (reserve.up.size() > 0){ // if there are face up cards
                while (!reserve.up.empty()){
                    // here's how you add it to the "bottom" of the stack
                    reserve.down.insertElementAt(reserve.up.pop(), 0);
                }
            }
            // now pop three from the faced DOWN section to the UP section
            for(int i=0;i<3;i++){
                reserve.up.push(reserve.down.pop());
            }
        }
    }
    
    /*
    @Override
    public String toString(){
        return "\t\t\t\t"+suit[0].up+"\t\t"+suit[1].up+"\t\t"+suit[2].up+"\t\t"+suit[3].up
                +"\n"+"|"+reserve[0].up+"\t\t"+reserve[1].up+"\t\t"+reserve[2];
    } 
     */
}
