/*
 * Heres the moves that the smart player makes
 */
package solitaire;

public class SSmartPlayer extends SPlayer {

    public SSmartPlayer(SGame game){
        super(game);
        // 1st rule in our Powerpoint was to hit the Reserve immediately
        game.drawThree();
        
        // Sequence of moves
        // 1) See if Reserve can go on Suit stacks
        // 2) See if Reserve can go on Piles
        // 3) See if items on Piles can go to Suit stacks
        

        boolean canMove = false;
        int canSuit = -1;
        
        // 1)
        do{
            // Can you move it to the Suit Stack?
            System.out.println("TESTING 1): "+game.reserve.up.peek()+" to SUIT STACK");
            canSuit = super.moveCardtStack(game.reserve.up.peek(), game.suit);
            if (canSuit != -1){
                // Found a match, so move it
                moves.add("<RESERVE: "+game.reserve.up.peek()+" to <Suit STACK["+canSuit+"]>");
                //System.out.println(moves.indexOf(moves.size()-1));
                System.out.println("COOL: "+moves.peek());
                game.suit[canSuit].up.add(game.reserve.up.pop());
            }            
        } while (canSuit != -1); // keep going until you can't anymore, then to next intelligent move
        
        // 2)
        do{
            // Can you move it to one of the 7 Piles?
            for (int i=0;i<7;i++){
                System.out.println("TESTING 2): "+game.reserve.up.peek()+" to "+ game.pile[i]);
                canMove = super.moveCardtStack(game.reserve.up.peek(), game.pile[i]);
                if (canMove){
                    // Found a match, so move it
                }
            }
        } while (canMove); // keep going until you can't anymore, then to next intelligent move
        
        // 3)
        do{
            // Can an item on a pile go in the Suit Stack?
            for (int i=0;i<7;i++){
                System.out.println("TESTING 3): "+game.pile[i].up.peek()+" to SUIT STACK");
                canSuit = super.moveCardtStack(game.pile[i].up.peek(), game.suit);
                if (canSuit != -1){
                    // Found a match, so move it
                    moves.add("<PILE["+i+"]: "+game.pile[i].up.peek()+" to <Suit STACK["+canSuit+"]>");
                    //System.out.println(moves.indexOf(moves.size()-1));
                    System.out.println("COOL: "+moves.peek());
                    game.suit[canSuit].up.add(game.pile[i].up.pop());
                }
            }
        } while (canSuit != -1);
        
        System.out.println("can this go on the suit stack? "+canMove);
        
        System.out.println("Weve made a new Smart Player");
        
        //System.out.println("he sees that the size of the reserve is "+game.reserve.up.size());
        
    }
}