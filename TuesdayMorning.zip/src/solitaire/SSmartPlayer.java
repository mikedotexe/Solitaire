/*
 * Heres the moves that the smart player makes
 */
package solitaire;

import java.util.Stack;

public class SSmartPlayer extends SPlayer {
    Stack<String> recipMoves = new Stack<String>(); // Reciprocal moves, so we don't move it to where it was
    public boolean QCDebug = false; // Quality Control, this will output every comparison to make sure it's working properly. Feel free to check it out.

    public SSmartPlayer(SGame game, boolean verbose){
        super(game);
        if (verbose) QCDebug = true;
        play();
    }
    public void play(){
        // 1st rule in our Powerpoint was to hit the Reserve immediately
        game.drawThree();
        // mark it in the moves Stack and print to screen
        moves.add("<Deal 3 cards from Reserve>"); System.out.println(moves.peek());

        // Sequence of moves
        // 1) See if Reserve can go on Suit stacks
        // 2) See if Reserve can go on Piles
        // 3) See if items on Piles can go to Suit stacks
        // 4) See if items on Piles can go to other Piles
        // 5) Test cards in middle of piles

        boolean canMove = false;
        int canSuit = -1;
        // before we loop through these steps, we check to see if we're in a deadlock.
        //
        boolean deadLock; // to be used in the do while below
        
        do{
            // Set deadlock to TRUE inside loop, then anytime a card is moved, it'll FALSE it
            deadLock = true;
            // 1) See if Reserve can go on Suit stacks
            do{
                // Can you move the Reserve top card to the Suit Stack?
                        //Quality Control Debugging
                        if (QCDebug) System.out.println("\tTESTING 1): RESERVE "+game.reserve.up.peek()+" to SUIT STACK");
                //canSuit = super.moveCardtStack(game.reserve.up.peek(), game.suit);
                canSuit = super.moveCardtStack(game.reserve, game.suit);
                if (canSuit != -1){
                    // Found a match, so move it
                    moves.add("<1) RESERVE: "+game.reserve.up.peek()+" to <Suit STACK["+canSuit+"]>");
                    // if this has already been added to history, get outta here!
                    if (game.history.containsKey(moves.peek())) continue;
                    System.out.println(moves.peek()); 
                    // Add to history
                    game.history.put(moves.peek(), canSuit); // the second argument is inconsequential
                    // ACTUALLY MOVE THE CARD
                    game.suit[canSuit].up.add(game.reserve.up.pop());
                    // Check to see if we need to deal 3 more cards from Reserve
                    need3More();
                    deadLock = false;
                }
            } while (canSuit != -1); // keep going until you can't anymore, then to next intelligent move

            // 2) See if Reserve can go on Piles
            do{
                // Can you move the Reserve top card to one of the 7 Piles?
                for (int i=0;i<7;i++){
                        //Quality Control Debugging
                        if (QCDebug) System.out.println("\tTESTING 2): "+game.reserve.up.peek()+" to "+ game.pile[i]);
                    //canMove = super.moveCardtStack(game.reserve.up.peek(), game.pile[i]);
                    canMove = super.moveCardtStack(game.reserve, game.pile[i]);
                    if (canMove){
                        // Found a match, so move it
                        moves.add("<2) RESERVE: "+game.reserve.up.peek()+" to Pile["+ i+"]>");
                        // if this has already been added to history, get outta here!
                        if (game.history.containsKey(moves.peek())) continue;
                        System.out.println(moves.peek()); 
                        // Add to history
                        game.history.put(moves.peek(), canSuit); // the second argument is inconsequential
                        // ACTUALLY MOVE THE CARD
                        game.pile[i].up.add(game.reserve.up.pop());
                        // Check to see if we need to deal 3 more cards from Reserve
                        need3More();
                        deadLock = false;
                    }
                }
            } while (canMove); // keep going until you can't anymore, then to next intelligent move

            // 3) See if items on Piles can go to Suit stacks
            do{
                // Can an item on a pile go in the Suit Stack?
                for (int i=0;i<7;i++){
                        //Quality Control Debugging
                        if (QCDebug){
                            if (game.pile[i].up.isEmpty())
                                System.out.println("\tTESTING 3): Pile["+i+"] EMPTY to SUIT STACK");
                            else
                                System.out.println("\tTESTING 3): Pile["+i+"] "+game.pile[i].up.peek()+" to SUIT STACK");
                        }
                    //canSuit = super.moveCardtStack(game.pile[i].up.peek(), game.suit);
                    canSuit = super.moveCardtStack(game.pile[i], game.suit);
                    if (canSuit != -1){
                        // Found a match, so move it
                        moves.add("<3) PILE["+i+"]: "+game.pile[i].up.peek()+" to Suit STACK["+canSuit+"]>");
                        // if this has already been added to history, get outta here!
                        if (game.history.containsKey(moves.peek())) continue;
                        System.out.println(moves.peek()); 
                        // Add to history
                        game.history.put(moves.peek(), canSuit); // the second argument is inconsequential
                        // ACTUALLY MOVE THE CARD
                        game.suit[canSuit].up.add(game.pile[i].up.pop());
                        // Flip 'um?
                        needFlipUm(i);
                        deadLock = false;
                    }
                }
            } while (canSuit != -1);

            // 4) See if items on Piles can go to other Piles
            do{
                // Can items on Piles go to other Piles?
                // Notice the SmartPlayer does this part in REVERSE ORDER
                int i=6;
                for (;i>=0;i--){
                    for (int j=0;j<7;j++){
                        if (game.pile[i].up.isEmpty()) continue; // cant move crap from an empty pile
                        if (j==i) continue; // don't test against itself
                            //Quality Control Debugging
                            if (QCDebug){
                                if (game.pile[j].up.isEmpty())
                                        System.out.println("\tTESTING 4): Pile["+i+"] "+game.pile[i].up.peek()+" to Pile["+j+"] (EMPTY)");
                                else
                                        System.out.println("\tTESTING 4): Pile["+i+"] "+game.pile[i].up.peek()+" to Pile["+j+"]'s "+game.pile[j].up.peek());
                            }
                            //canMove = super.moveCardtStack(game.pile[i].up.peek(), game.pile[j]);
                            canMove = super.moveCardtStack(game.pile[i], game.pile[j]);
                        if (canMove){
                            // Found a match, so move it
                                moves.add("<4) Pile["+i+"] "+game.pile[i].up.peek()+" to Pile["+j+"]>");
                                //recipMoves.add("<4) Pile["+j+"] "+game.pile[j].up.peek()+" to Pile["+i+"] "+game.pile[i].up.peek()+">");
                                // if this has already been added to history, get outta here!
                                if (game.history.containsKey(moves.peek())){
                                    // This part is unique to SmartPlayer
                                    // Even if it's in the history, if it's moving stuff towards
                                    // lower piles, that's generally a good heuristic
                                    if (i<j){
                                        continue;
                                    }
                                }
                                /*
                                if (game.history.containsKey(recipMoves.peek())){
                                    System.out.println("VERY INTERESTING");
                                    continue;
                                }
                                 */
                                
                                System.out.println(moves.peek()); 
                                // Add to history
                                game.history.put(moves.peek(), canSuit); // the second argument is inconsequential
                                // ACTUALLY MOVE THE CARD
                                game.pile[j].up.add(game.pile[i].up.pop());
                                // Flip 'um?
                                needFlipUm(i);   
                                deadLock = false;
                                continue; // dont keep checking the same card once it's moved
                        }
                    }
                }
            } while (canMove);
            
            
            // 5) Test cards in middle of piles
            do{
                for (int i=6;i>=0;i--){
                    if (game.pile[i].up.size() > 1){
                        for (int j=0;j<7;j++){
                            if (QCDebug) System.out.println("\tTESTING 5): MidPile["+i+"] to Pile["+j+"]");
                            canMove = super.moveMiddle(game.pile[i], game.pile[j], i, j, true);
                            if (canMove) {
                                // By this time the cards have already been moved       
                                needFlipUm(i);   
                                //deadLock = false;                                
                            }
                        }
                    }
                }
            } while (canMove);
            
            /*
            System.out.println("**********************************");
            System.out.println("Going for another round, RESERVE_COUNT is "+game.RESERVE_COUNT);
            System.out.println("**********************************");
             */
            if (game.RESERVE_COUNT == 0) deadLock = true;
            if (deadLock == false) {
                System.out.println("Trying AI techniques again...");
            }
            
        } while (deadLock == false);
        
        System.out.println("Exited with deadLock: "+deadLock+" and RESERVE_COUNT as "+game.RESERVE_COUNT);
        int Score = game.getScore();
        System.out.println("-------------------------------------------------------");
        System.out.println("SCORE: "+Score+" cards in Suit Stacks");
        System.out.println("-------------------------------------------------------");
        System.out.println();

        
        
        
        
        
        //System.out.println("Weve made a new Smart Player");
        
        //System.out.println("he sees that the size of the reserve is "+game.reserve.up.size());
        
    }
    
    public void need3More(){
        if (game.reserve.up.size() == 0 && game.reserve.down.size() > 0){
            // Deal three cards from the Reserve
            game.drawThree();
            // mark it in the moves Stack and print to screen
            moves.add("<Deal 3 cards from Reserve>"); System.out.println(moves.peek());
        }        
    }
    
    public void needFlipUm(int n){
        // Will always refer to a Pile
        if (game.pile[n].up.size() == 0 && game.pile[n].down.size() > 0){
            moves.add("Flip <Pile["+n+"]>");
            System.out.println(moves.peek());
            game.pile[n].up.add(game.pile[n].down.pop());
        }
    }
}