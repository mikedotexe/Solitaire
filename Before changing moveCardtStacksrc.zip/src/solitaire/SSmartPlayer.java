/*
 * Heres the moves that the smart player makes
 */
package solitaire;

public class SSmartPlayer extends SPlayer {

    public SSmartPlayer(SGame game){
        super(game);
        boolean QCDebug = true; // Quality Control, this will output every comparison to make sure it's working properly. Feel free to check it out.
        // 1st rule in our Powerpoint was to hit the Reserve immediately
        game.drawThree();
        // mark it in the moves Stack and print to screen
        moves.add("<Deal 3 cards from Reserve>"); System.out.println(moves.peek());

        // Sequence of moves
        // 1) See if Reserve can go on Suit stacks
        // 2) See if Reserve can go on Piles
        // 3) See if items on Piles can go to Suit stacks
        // 4) See if items on Piles can go to other Piles

        boolean canMove = false;
        int canSuit = -1;
        
        // 1)
        do{
            // Can you move the Reserve top card to the Suit Stack?
                    //Quality Control Debugging
                    if (QCDebug) System.out.println("\tTESTING 1): "+game.reserve.up.peek()+" to SUIT STACK");
            canSuit = super.moveCardtStack(game.reserve.up.peek(), game.suit);
            if (canSuit != -1){
                // Found a match, so move it
                moves.add("<1) RESERVE: "+game.reserve.up.peek()+" to <Suit STACK["+canSuit+"]>");
                System.out.println(moves.peek());
                game.suit[canSuit].up.add(game.reserve.up.pop());
                // Check to see if we need to deal 3 more cards from Reserve
                need3More();
            }
        } while (canSuit != -1); // keep going until you can't anymore, then to next intelligent move
        
        // 2)
        do{
            // Can you move the Reserve top card to one of the 7 Piles?
            for (int i=0;i<7;i++){
                    //Quality Control Debugging
                    if (QCDebug) System.out.println("\tTESTING 2): "+game.reserve.up.peek()+" to "+ game.pile[i]);
                canMove = super.moveCardtStack(game.reserve.up.peek(), game.pile[i]);
                if (canMove){
                    // Found a match, so move it
                    moves.add("<2) RESERVE: "+game.reserve.up.peek()+" to Pile["+ i+"]>");
                    System.out.println(moves.peek());
                    game.pile[i].up.add(game.reserve.up.pop());
                    // Check to see if we need to deal 3 more cards from Reserve
                    need3More();
                }
            }
        } while (canMove); // keep going until you can't anymore, then to next intelligent move
        
        // 3)
        do{
            // Can an item on a pile go in the Suit Stack?
            for (int i=0;i<7;i++){
                    //Quality Control Debugging
                    if (QCDebug) System.out.println("\tTESTING 3): Pile["+i+"] "+game.pile[i].up.peek()+" to SUIT STACK");
                canSuit = super.moveCardtStack(game.pile[i].up.peek(), game.suit);
                if (canSuit != -1){
                    // Found a match, so move it
                    moves.add("<3) PILE["+i+"]: "+game.pile[i].up.peek()+" to <Suit STACK["+canSuit+"]>");
                    System.out.println(moves.peek());
                    game.suit[canSuit].up.add(game.pile[i].up.pop());
                    // Flip 'um?
                    needFlipUm(i);
                }
            }
        } while (canSuit != -1);
        
        // 4)
        do{
            // Can items on Piles go to other Piles?
            // Notice the SmartPlayer does this part in REVERSE ORDER
            int i=6;
            for (;i>=0;i--){
                for (int j=0;j<7;j++){
                        //Quality Control Debugging
                        if (QCDebug){
                            if (game.pile[j].up.isEmpty())
                                try{
                                    System.out.println("\tTESTING 4): Pile["+i+"] "+game.pile[i].up.peek()+" to Pile["+j+"]");
                                } catch (Exception e){
                                    System.out.println("4) Weird1 "+e.toString());
                                }
                            else
                                try{
                                    System.out.println("\tTESTING 4): Pile["+i+"] "+game.pile[i].up.peek()+" to Pile["+j+"]'s "+game.pile[j].up.peek());
                                } catch (Exception e){
                                    System.out.println("4) Weird2 "+e.toString());
                                }
                                
                        }
                    try{
                        canMove = super.moveCardtStack(game.pile[i].up.peek(), game.pile[j]);
                    } catch (Exception e){
                        System.out.println("4) AHA! "+e.toString());
                    }
                    if (canMove){
                        // Found a match, so move it
                        try{
                            moves.add("<4) Pile["+i+"] "+game.pile[i].up.peek()+" to Pile["+j+"]>");
                            System.out.println(moves.peek());
                            game.pile[j].up.add(game.pile[i].up.pop());
                            // Flip 'um?
                            needFlipUm(i);                        
                        } catch (Exception e){
                            System.out.println("4) BELOW "+e.toString());
                        }
                    }
                }
            }
        } while (canMove);

        
        
        
        
        
        System.out.println("can this go on the suit stack? "+canMove);
        
        System.out.println("Weve made a new Smart Player");
        
        //System.out.println("he sees that the size of the reserve is "+game.reserve.up.size());
        
    }
    
    public void need3More(){
        if (game.reserve.up.size() == 0 && game.reserve.down.size() > 0){
            // Deal three cards from the Reserve
            game.drawThree();
            // mark it in the moves Stack and print to screen
            moves.add("<Deal 3 cards from Reserve>"); System.out.println(moves.peek());
        }        
    }
    
    public void needFlipUm(int n){
        // Will always refer to a Pile
        if (game.pile[n].up.size() == 0 && game.pile[n].down.size() > 0){
            moves.add("Flip <Pile["+n+"]>");
            System.out.println(moves.peek());
            game.pile[n].up.add(game.pile[n].down.pop());
        }
    }
}